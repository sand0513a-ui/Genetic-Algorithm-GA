import random
import string

# 1. 문제 설정: 목표 문자열 정의 (GA가 찾아야 할 해답)
TARGET = "HELLO"
TARGET_LEN = len(TARGET)
POPULATION_SIZE = 100  # 한 세대의 염색체(후보) 개수
MUTATION_RATE = 0.05  # 돌연변이 발생 확률

# 가능한 문자 집합 (대문자 A-Z와 공백)
GENES = string.ascii_uppercase + " "

## 2. 핵심 함수: 적합도 평가 (Fitness Function)

def calculate_fitness(individual):
    """
    각 염색체(후보 문자열)가 목표 문자열과 얼마나 일치하는지 점수(적합도)를 계산합니다.
    일치하는 문자 개수가 많을수록 점수가 높음.
    """
    fitness = 0
    for gene_a, gene_b in zip(individual, TARGET):
        if gene_a == gene_b:
            fitness += 1
    return fitness

## 3. GA 연산: 생성, 선택, 교차, 돌연변이

# 3.1. 초기 해 생성 (Initialization)
def create_individual():
    """목표 길이만큼 무작위 문자로 이루어진 염색체(개체)를 만듭니다."""
    return ''.join(random.choice(GENES) for _ in range(TARGET_LEN))

# 3.2. 개체군 생성 (Population)
def create_initial_population():
    return [create_individual() for _ in range(POPULATION_SIZE)]

# 3.3. 선택 및 교차 (Selection & Crossover)
def selection_and_crossover(population):
    # 적합도에 비례하여 부모를 선택 (룰렛휠 방식 간소화)
    weighted_pool = []
    for individual in population:
        fitness = calculate_fitness(individual)
        # 점수가 높을수록 풀에 많이 넣어 선택될 확률을 높임
        weighted_pool.extend([individual] * fitness)

    new_population = []
    while len(new_population) < POPULATION_SIZE:
        # 부모 2명 선택
        parent1 = random.choice(weighted_pool)
        parent2 = random.choice(weighted_pool)

        # 교차 (Crossover)
        crossover_point = random.randint(1, TARGET_LEN - 1)
        child = parent1[:crossover_point] + parent2[crossover_point:]
        
        new_population.append(child)
    return new_population

# 3.4. 돌연변이 (Mutation)
def mutate(individual):
    """일정 확률로 개체의 특정 문자를 무작위로 변경함."""
    mutated_individual = list(individual)
    for i in range(TARGET_LEN):
        if random.random() < MUTATION_RATE:
            # 돌연변이 발생!
            mutated_individual[i] = random.choice(GENES)
    return "".join(mutated_individual)

## 4. 메인 GA 루프 실행

def run_ga():
    population = create_initial_population()
    generation = 0

    print("--- 유전자 알고리즘 시연 시작 ---")
    
    while True:
        # 1. 적합도 평가 및 정렬
        # (최적의 해가 맨 앞에 오도록 정렬)
        population.sort(key=calculate_fitness, reverse=True)
        
        best_individual = population[0]
        max_fitness = calculate_fitness(best_individual)

        # 현재 세대의 최고 해와 점수를 출력
        print(f"세대: {generation:4} | 최고 적합도: {max_fitness}/{TARGET_LEN} | 최고 해: {best_individual}")

        # 2. 종료 조건 확인
        if best_individual == TARGET:
            print("\n!!! 목표 해답을 찾았습니다. 시연 종료. !!!")
            break

        # 3. 다음 세대 생성
        # (선택, 교차, 돌연변이)
        next_population = []
        
        # 상위 10% 엘리트 보존 (Elitism)
        elite_size = int(POPULATION_SIZE * 0.1)
        next_population.extend(population[:elite_size])

        # 나머지 개체 생성
        children_after_crossover = selection_and_crossover(population)
        
        for child in children_after_crossover:
            mutated_child = mutate(child)
            next_population.append(mutated_child)

        # 다음 세대로 교체
        population = next_population
        generation += 1

# 코드 실행
if __name__ == "__main__":
    run_ga()